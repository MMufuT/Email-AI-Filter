require 'active_support/core_ext/object/to_query'
