module I18n
  VERSION = "0.9.5"
end
